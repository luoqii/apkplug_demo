package com.apkplugdemo.adapter;

import org.osgi.framework.Bundle;

import com.apkplug.CloudService.model.appModel;

public class BundleStutes {
	public Bundle b=null;
	public appModel ab=null;
	public String appid=null;
	public int updatastutes=0;
}
