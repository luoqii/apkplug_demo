/** Automatically generated file. DO NOT MODIFY */
package com.apkplug.bundle.manager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}