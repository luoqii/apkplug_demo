package com.apkplug.defaultosgiclient;

import android.app.Activity;
import android.os.Bundle;

public class testActivity extends Activity{
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.testactivity);
	}
}
