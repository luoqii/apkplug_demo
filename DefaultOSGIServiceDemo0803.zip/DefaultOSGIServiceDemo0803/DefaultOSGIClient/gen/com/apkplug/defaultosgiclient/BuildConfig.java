/** Automatically generated file. DO NOT MODIFY */
package com.apkplug.defaultosgiclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}